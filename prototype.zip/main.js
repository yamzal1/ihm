const title = document.querySelector("#title");
const h = document.querySelector("#home");
const desktop = document.querySelector("#desktop");
const keyboard = document.querySelector("#keyboard");
const mouse = document.querySelector("#mouse");

const show = function (str) {
    switch (str) {
        case "keyboard":
            h.classList.replace("visible", "hide");
            keyboard.classList.replace("hide", "visible");
            title.innerText = "Keyboard Configurator";
            break;
        case "mouse":
            h.classList.replace("visible", "hide");
            mouse.classList.replace("hide", "visible");
            title.innerText = "Mouse Configurator";
            break;
        case "desktop":
            h.classList.replace("visible", "hide");
            desktop.classList.replace("hide", "visible");
            title.innerText = "Desktop Configurator";
            break;
        default:
            document.querySelector(".visible").classList.replace("visible", "hide");
            h.classList.replace("hide", "visible");
            title.innerText = "Configurator";
            break;
    }
}

document.querySelector("#tokeyboard").onclick = () => show("keyboard");
document.querySelector("#tomouse").onclick = () => show("mouse");
document.querySelector("#todesktop").onclick = () => show("desktop");
[...document.querySelectorAll(".confirm")].forEach(e => { e.onclick = show });